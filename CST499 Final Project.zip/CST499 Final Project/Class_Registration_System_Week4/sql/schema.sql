-- USERS TABLE
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- COURSES TABLE
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL,
    semester VARCHAR(20) NOT NULL
);

-- REGISTRATIONS TABLE
CREATE TABLE registrations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

-- SAMPLE COURSE DATA
INSERT INTO courses (course_name, semester) VALUES
('Introduction to Programming', 'Fall 2025'),
('Object-Oriented Programming in Java', 'Fall 2025'),
('Database Systems', 'Fall 2025'),
('Web Development Fundamentals', 'Fall 2025'),
('Software Engineering Principles', 'Spring 2026'),
('Mobile App Development', 'Spring 2026'),
('Data Structures and Algorithms', 'Spring 2026'),
('Cloud Computing Essentials', 'Summer 2026'),
('Cybersecurity Basics', 'Summer 2026'),
('Capstone Project in Software Development', 'Summer 2026');
