<?php
include 'Database.php';
$db = new Database();
$conn = $db->getConnection();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!empty($username) && strlen($password) >= 6) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed);
        if ($stmt->execute()) {
            echo "Registration successful. <a href='login.php'>Login now</a>.";
        } else {
            echo "Username already taken.";
        }
    } else {
        echo "Invalid input.";
    }
}
?>

<form method="POST">
    Username: <input type="text" name="username"><br>
    Password (min 6 chars): <input type="password" name="password"><br>
    <input type="submit" value="Register">
</form>