<?php
session_start();
if (isset($_SESSION['user_id'])) {
    echo "Welcome! <a href='courses.php'>Register for Classes</a> | <a href='my_courses.php'>My Schedule</a> | <a href='logout.php'>Logout</a>";
} else {
    echo "<a href='login.php'>Login</a> | <a href='register.php'>Register</a>";
}
?>