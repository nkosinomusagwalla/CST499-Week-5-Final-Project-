<?php
session_start();
include 'Database.php';
$db = new Database();
$conn = $db->getConnection();

$reg_id = $_GET['reg_id'];
$conn->query("DELETE FROM registrations WHERE id=$reg_id");

header("Location: my_courses.php");
?>