<?php
session_start();
include 'Database.php';
$db = new Database();
$conn = $db->getConnection();

$user_id = $_SESSION['user_id'];

$result = $conn->query("
    SELECT registrations.id as reg_id, courses.course_name, courses.semester 
    FROM registrations 
    JOIN courses ON registrations.course_id = courses.id 
    WHERE registrations.user_id = $user_id
");

echo "<h2>My Registered Courses</h2>";
while ($row = $result->fetch_assoc()) {
    echo "{$row['course_name']} ({$row['semester']}) 
        <a href='delete_course.php?reg_id={$row['reg_id']}'>Drop</a><br>";
}
?>