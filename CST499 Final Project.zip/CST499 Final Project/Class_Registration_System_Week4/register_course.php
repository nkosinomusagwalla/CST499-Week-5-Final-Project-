<?php
session_start();
include 'Database.php';
$db = new Database();
$conn = $db->getConnection();

$user_id = $_SESSION['user_id'];
$course_ids = $_POST['course_ids'];

foreach ($course_ids as $course_id) {
    $check = $conn->query("SELECT * FROM registrations WHERE user_id=$user_id AND course_id=$course_id");
    if ($check->num_rows == 0) {
        $conn->query("INSERT INTO registrations (user_id, course_id) VALUES ($user_id, $course_id)");
    }
}
header("Location: my_courses.php");
?>