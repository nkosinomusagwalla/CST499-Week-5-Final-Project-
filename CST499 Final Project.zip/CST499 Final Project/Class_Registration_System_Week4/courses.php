<?php
session_start();
include 'Database.php';
$db = new Database();
$conn = $db->getConnection();

$result = $conn->query("SELECT * FROM courses");
echo "<h2>Available Courses</h2>";
echo "<form method='POST' action='register_course.php'>";
while ($row = $result->fetch_assoc()) {
    echo "<input type='checkbox' name='course_ids[]' value='{$row['id']}'> {$row['course_name']} ({$row['semester']})<br>";
}
echo "<input type='submit' value='Register'>";
echo "</form>";
?>