<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Welcome - Class Registration System</title>
</head>
<body>
    <h1>Welcome to the Student Class Registration System</h1>
    <?php if (isset($_SESSION['user'])): ?>
        <p>Hello, <?= htmlspecialchars($_SESSION['user']) ?>! <a href='logout.php'>Logout</a></p>
    <?php else: ?>
        <p><a href='login.php'>Login</a> | <a href='register.php'>Register</a></p>
    <?php endif; ?>
</body>
</html>
